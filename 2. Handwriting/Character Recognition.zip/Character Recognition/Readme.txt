Please download the model file from the following link,
https://github.com/codemaker2015/Handwritting/blob/master/model/model.zip

For Full source code:

https://github.com/codemaker2015/Handwritting