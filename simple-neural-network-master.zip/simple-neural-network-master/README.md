# Simple Neural Network
A neural network written in Python, consisting of a single neuron that uses back propagation to learn.

### Dependencies
1. numpy
